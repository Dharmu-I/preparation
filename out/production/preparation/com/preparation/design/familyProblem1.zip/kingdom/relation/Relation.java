package com.preparation.design.kingdom.relation;

import java.util.List;

public interface Relation {

    List<String> getRelationDetails(String name);
}
