package com.preparation.design.kingdom.enums;

public enum RelationOfKing {
    Father,
    Mother
}
