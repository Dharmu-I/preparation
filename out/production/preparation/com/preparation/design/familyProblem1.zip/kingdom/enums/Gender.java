package com.preparation.design.kingdom.enums;

public enum Gender {
    Male,
    Female
}
